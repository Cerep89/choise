<?php require('includes/connection.php'); ?>
<?php require_once('includes/functions.php'); ?>
<?php 
	$name = $_POST['name'];
	$position = $_POST['position'];
	$visible =  $_POST['visible'];
	$content =  $_POST['content'];

	$errors = [];
	$field_names = [$name, $position, $visible, $content];
	foreach ($field_names as $key => $field) {
		$field = trim($field);
		if(!isset($field) OR empty($field)){
			$errors[] = $field;
		}
	}

	if(!empty($errors)){
		header("Location: new_subject.php");
		exit;
	}

	$insert_query = "INSERT INTO subjects 
						(name, position, visible, content) 
			 			VALUES 
						('{$name}', {$position}, {$visible}, '{$content}') ";
//	echo $inset_query;
	$result = $connection->query($insert_query);
	if($result){
		header("Location: new_subject.php");
		exit;
	}else{
		echo "Создание нового раздела не удалось: ";
	}
?>
